# Billiards Overlay

تطبيق Android يرسم خطوط مسار الكرات ودوائرها فوق لعبتك.

## التشغيل
1. افتح مجلد المشروع في Android Studio ودعه يعمل Sync (يحتاج JDK 17).
2. شغّل التطبيق على الهاتف.
3. اضغط "منح إذن الظهور فوق التطبيقات" ثم فعّل الإذن.
4. اضغط "تشغيل الطبقة" ثم "تجربة" لترى خطاً تجريبياً.

## الربط مع لعبتك
لعبتك ترسل Broadcast في كل مرة يتغير فيها السحب أو موقع الكرات.
الإحداثيات كلها بالبكسل **على الشاشة** (استخدم view.getLocationOnScreen لتحويل إحداثيات اللعبة).

```kotlin
fun sendToOverlay(ctx: Context) {
    val json = JSONObject()
        .put("table", JSONObject()
            .put("l", 120).put("t", 90).put("r", 1800).put("b", 990)   // منطقة اللعب داخل الحواف
            .put("ballR", 22))
        .put("balls", JSONArray()
            .put(JSONObject().put("id", 0).put("x", 400).put("y", 540))  // id 0 = البيضاء
            .put(JSONObject().put("id", 1).put("x", 900).put("y", 560)))
        .put("aim", JSONObject().put("dx", 1.0).put("dy", 0.0).put("speed", 2200))
        .put("friction", 600)          // px/s² — عدّله حتى يطابق لعبتك
    ctx.sendBroadcast(
        Intent("com.example.billiardhelper.UPDATE")
            .setPackage("com.example.billiardhelper")
            .putExtra("json", json.toString())
    )
}
// لإخفاء الخطوط: {"clear": true}
```

حقول اختيارية: `pockets` (مصفوفة [x,y])، `pocketR`، `eBall`، `eCushion`.
إن لم ترسل الجيوب تُحسب 6 جيوب من حدود الطاولة.

## المعايرة
اضبط friction و eBall و eCushion و speed (px/s) بتجربة ضربة في لعبتك ومقارنتها بالخطوط حتى تتطابق.
الدوران (Spin) غير مدعوم حالياً.
