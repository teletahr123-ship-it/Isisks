package com.example.billiardhelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

class OverlayService : Service() {

    companion object {
        const val ACTION_UPDATE = "com.example.billiardhelper.UPDATE"
        private const val CHANNEL = "overlay"
        private const val TAG = "BilliardsOverlay"
    }

    private lateinit var wm: WindowManager
    private var view: TrajectoryView? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val latest = AtomicReference<String?>(null)

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val json = intent.getStringExtra("json") ?: return
            latest.set(json)                       // نحتفظ بآخر رسالة فقط
            worker.execute { latest.getAndSet(null)?.let { handle(it) } }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundCompat()
        addOverlay()
        val filter = IntentFilter(ACTION_UPDATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_EXPORTED)
        else registerReceiver(receiver, filter)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        unregisterReceiver(receiver)
        view?.let { wm.removeView(it) }
        view = null
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Billiards Overlay يعمل")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun addOverlay() {
        val v = TrajectoryView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or      // اللمس يمر للعبة
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        view = v
    }

    /** يحلل الرسالة، يشغل المحاكاة، ويرسم النتيجة */
    private fun handle(text: String) {
        try {
            val o = JSONObject(text)
            if (o.optBoolean("clear", false)) { view?.clear(); return }

            val tb = o.getJSONObject("table")
            val l = tb.getDouble("l"); val t = tb.getDouble("t")
            val rr = tb.getDouble("r"); val b = tb.getDouble("b")
            val ballR = tb.getDouble("ballR")
            val pocketR = tb.optDouble("pocketR", ballR * 1.6)

            val pockets = ArrayList<Vec>()
            if (o.has("pockets")) {
                val arr = o.getJSONArray("pockets")
                for (i in 0 until arr.length()) {
                    val p = arr.getJSONArray(i)
                    pockets.add(Vec(p.getDouble(0), p.getDouble(1)))
                }
            } else {
                val mx = (l + rr) / 2
                pockets.addAll(listOf(
                    Vec(l, t), Vec(mx, t), Vec(rr, t),
                    Vec(l, b), Vec(mx, b), Vec(rr, b)
                ))
            }
            val table = Table(l, t, rr, b, ballR, pockets, pocketR)

            val aim = o.getJSONObject("aim")
            val dir = Vec(aim.getDouble("dx"), aim.getDouble("dy")).norm()
            val speed = aim.getDouble("speed")

            val arr = o.getJSONArray("balls")
            val balls = ArrayList<Ball>()
            for (i in 0 until arr.length()) {
                val ob = arr.getJSONObject(i)
                val id = ob.getInt("id")
                val pos = Vec(ob.getDouble("x"), ob.getDouble("y"))
                balls.add(Ball(id, pos, if (id == 0) dir * speed else Vec(0.0, 0.0)))
            }

            val rules = Rules(
                friction = o.optDouble("friction", 600.0),
                eBall = o.optDouble("eBall", 0.95),
                eCushion = o.optDouble("eCushion", 0.75)
            )
            view?.show(Sim.run(balls, table, rules), ballR)
        } catch (e: Exception) {
            Log.e(TAG, "رسالة غير صالحة", e)
        }
    }
}
