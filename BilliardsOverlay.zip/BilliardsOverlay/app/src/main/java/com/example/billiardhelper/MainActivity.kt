package com.example.billiardhelper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Billiards Overlay\nخطوط المسار فوق لعبتك"
            textSize = 20f
            setPadding(0, 0, 0, pad)
        })

        fun button(label: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }

        button("1) منح إذن الظهور فوق التطبيقات") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("2) تشغيل الطبقة") { startOverlay() }
        button("إيقاف الطبقة") { stopService(Intent(this, OverlayService::class.java)) }
        button("تجربة (رسم مثال)") { sendDemo() }
        button("إخفاء الخطوط") { send(JSONObject().put("clear", true)) }

        setContentView(root)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "امنح إذن الظهور فوق التطبيقات أولاً", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
    }

    private fun send(json: JSONObject) {
        sendBroadcast(
            Intent(OverlayService.ACTION_UPDATE)
                .setPackage(packageName)
                .putExtra("json", json.toString())
        )
    }

    /** مثال: بيضاء تضرب كرة قريبة من منتصف الطاولة */
    private fun sendDemo() {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toDouble()
        val h = dm.heightPixels.toDouble()
        val l = w * 0.1; val r = w * 0.9; val t = h * 0.15; val b = h * 0.85
        val ballR = minOf(w, h) * 0.035
        val midY = (t + b) / 2

        fun ball(id: Int, x: Double, y: Double) = JSONObject().put("id", id).put("x", x).put("y", y)

        val json = JSONObject()
            .put("table", JSONObject().put("l", l).put("t", t).put("r", r).put("b", b).put("ballR", ballR))
            .put("balls", JSONArray()
                .put(ball(0, l + (r - l) * 0.20, midY))
                .put(ball(1, l + (r - l) * 0.50, midY + ballR * 0.8))
                .put(ball(2, l + (r - l) * 0.70, midY - ballR * 3)))
            .put("aim", JSONObject().put("dx", 1.0).put("dy", 0.0).put("speed", w * 1.2))
            .put("friction", w * 0.35)
        send(json)
    }
}
