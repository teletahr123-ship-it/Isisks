package com.example.billiardhelper

import android.content.Context
import android.content.SharedPreferences

/** يحفظ مفتاح Groq واسم النموذج داخل مساحة التطبيق الخاصة (وليس داخل الكود). */
object AiSettings {

    /** نموذج الرؤية المتاح حالياً في Groq (Llama 4 Scout أُوقف في 17 يوليو 2026) */
    const val DEFAULT_MODEL = "qwen/qwen3.8-27b"

    private const val PREFS = "ai_settings"

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun apiKey(ctx: Context): String = (prefs(ctx).getString("api_key", "") ?: "").trim()

    fun model(ctx: Context): String {
        val m = (prefs(ctx).getString("model", "") ?: "").trim()
        return if (m.isEmpty()) DEFAULT_MODEL else m
    }

    /** يُبقي الرموز المرئية ASCII فقط: أي مسافة أو رمز خفي يلتصق بالمفتاح عند اللصق يُحذف */
    fun sanitizeKey(raw: String): String = raw.filter { it.code in 33..126 }

    fun save(ctx: Context, key: String, model: String) {
        prefs(ctx).edit()
            .putString("api_key", sanitizeKey(key))
            .putString("model", model.trim())
            .apply()
    }

    /** عرض مخفي للمفتاح للتأكد من أنه حُفظ كاملاً دون كشفه */
    fun mask(key: String): String {
        if (key.length < 12) return "قصير جداً (" + key.length + " حرفاً)"
        return key.substring(0, 6) + "…" + key.substring(key.length - 4) + " (" + key.length + " حرفاً)"
    }
}
