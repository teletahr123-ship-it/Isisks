package com.example.billiardhelper

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.widget.Toast
import java.util.Locale

/** ينطق نصيحة الذكاء الاصطناعي بصوت عربي عبر محرك الصوت المدمج في الهاتف. */
object Speaker : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var appCtx: Context? = null

    @Volatile
    private var ready = false

    @Volatile
    private var pending: String? = null

    private val ui = Handler(Looper.getMainLooper())

    /** آمن للاستدعاء أكثر من مرة */
    fun prepare(ctx: Context) {
        if (tts != null) return
        val app = ctx.applicationContext
        appCtx = app
        tts = TextToSpeech(app, this)
    }

    override fun onInit(status: Int) {
        val engine = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            toast("تعذّر تشغيل محرك الصوت. فعّل «خدمات الكلام من Google» من إعدادات الهاتف.")
            return
        }
        val r = engine.setLanguage(Locale.forLanguageTag("ar"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            toast("صوت العربية غير مثبّت. ثبّته من الإعدادات > تحويل النص إلى كلام. سيُستخدم الصوت الافتراضي الآن.")
            engine.setLanguage(Locale.getDefault())
        }
        ready = true
        val p = pending
        if (p != null) {
            pending = null
            engine.speak(p, TextToSpeech.QUEUE_FLUSH, null, "ai")
        }
    }

    fun speak(text: String) {
        val engine = tts
        if (engine == null || !ready) {
            pending = text
            return
        }
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ai")
    }

    fun stop() {
        tts?.stop()
    }

    private fun toast(msg: String) {
        val c = appCtx ?: return
        ui.post { Toast.makeText(c, msg, Toast.LENGTH_LONG).show() }
    }
}
