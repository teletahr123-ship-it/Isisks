package com.example.billiardhelper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.View

class TrajectoryView(context: Context) : View(context) {

    @Volatile private var result: SimResult? = null
    @Volatile private var ballR = 20f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val dash = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    private val palette = intArrayOf(
        Color.YELLOW, Color.CYAN, Color.MAGENTA, Color.GREEN,
        Color.rgb(255, 165, 0), Color.rgb(255, 105, 180)
    )

    fun show(res: SimResult, radius: Double) {
        result = res
        ballR = radius.toFloat()
        postInvalidate()
    }

    fun clear() {
        result = null
        postInvalidate()
    }

    override fun onDraw(c: Canvas) {
        val res = result ?: return

        // مسار كل كرة تتحرك + دائرة على موقعها الحالي
        for ((id, pts) in res.paths) {
            if (pts.size < 2) continue
            val start = pts[0]
            if (pts.none { (it - start).len() > 2.0 }) continue   // كرة ثابتة

            paint.color = if (id == 0) Color.WHITE else palette[id % palette.size]
            paint.pathEffect = null
            val path = Path()
            path.moveTo(start.x.toFloat(), start.y.toFloat())
            for (i in 1 until pts.size) path.lineTo(pts[i].x.toFloat(), pts[i].y.toFloat())
            c.drawPath(path, paint)
            c.drawCircle(start.x.toFloat(), start.y.toFloat(), ballR, paint)
        }

        // كرة الشبح: مكان الكرة البيضاء لحظة أول لمس
        res.contactPos?.let {
            paint.color = Color.WHITE
            paint.pathEffect = dash
            c.drawCircle(it.x.toFloat(), it.y.toFloat(), ballR, paint)
            paint.pathEffect = null
        }

        // علامة على الجيب الذي تدخله الكرة
        for ((id, p) in res.pocketed) {
            paint.color = if (id == 0) Color.RED else Color.GREEN
            c.drawCircle(p.x.toFloat(), p.y.toFloat(), ballR * 1.2f, paint)
        }
    }
}
