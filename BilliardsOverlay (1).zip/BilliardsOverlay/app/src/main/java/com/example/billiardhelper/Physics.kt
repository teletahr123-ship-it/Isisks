package com.example.billiardhelper

import kotlin.math.max
import kotlin.math.sqrt

data class Vec(val x: Double, val y: Double) {
    operator fun plus(o: Vec) = Vec(x + o.x, y + o.y)
    operator fun minus(o: Vec) = Vec(x - o.x, y - o.y)
    operator fun times(k: Double) = Vec(x * k, y * k)
    fun dot(o: Vec) = x * o.x + y * o.y
    fun len() = sqrt(x * x + y * y)
    fun norm(): Vec {
        val l = len()
        return if (l == 0.0) this else this * (1.0 / l)
    }
}

class Ball(val id: Int, var pos: Vec, var vel: Vec = Vec(0.0, 0.0), var alive: Boolean = true)

/** كل القيم بالبكسل (الطول px، السرعة px/s، الاحتكاك px/s²). left/top/right/bottom = منطقة اللعب داخل الحواف */
class Table(
    val left: Double, val top: Double, val right: Double, val bottom: Double,
    val ballR: Double, val pockets: List<Vec>, val pocketR: Double
)

class Rules(
    val friction: Double,
    val eBall: Double = 0.95,
    val eCushion: Double = 0.75,
    val stopSpeed: Double = 5.0
)

class SimResult(
    val paths: Map<Int, List<Vec>>,
    val pocketed: Map<Int, Vec>,   // رقم الكرة -> مركز الجيب
    val contactPos: Vec?,          // موقع الكرة البيضاء لحظة أول لمس (كرة الشبح)
    val targetId: Int?             // الكرة التي لمستها البيضاء أولاً
)

object Sim {
    fun run(
        input: List<Ball>, t: Table, rules: Rules,
        dt: Double = 1.0 / 240, maxTime: Double = 8.0, sampleEvery: Int = 3
    ): SimResult {
        val balls = input.map { Ball(it.id, it.pos, it.vel) }
        val paths = balls.associate { it.id to mutableListOf(it.pos) }
        val pocketed = LinkedHashMap<Int, Vec>()
        var contact: Vec? = null
        var target: Int? = null

        val r = t.ballR
        val minX = t.left + r; val maxX = t.right - r
        val minY = t.top + r; val maxY = t.bottom - r
        val steps = (maxTime / dt).toInt()

        for (step in 1..steps) {
            val events = HashSet<Int>()

            // 1) الحركة + الاحتكاك
            for (b in balls) {
                if (!b.alive) continue
                b.pos = b.pos + b.vel * dt
                val s = b.vel.len()
                if (s > 0.0) b.vel = b.vel.norm() * max(0.0, s - rules.friction * dt)
            }

            // 2) الجيوب (قبل الحواف)
            for (b in balls) {
                if (!b.alive) continue
                for (p in t.pockets) {
                    if ((b.pos - p).len() < t.pocketR) {
                        b.alive = false
                        b.vel = Vec(0.0, 0.0)
                        b.pos = p
                        pocketed[b.id] = p
                        paths[b.id]!!.add(p)
                        break
                    }
                }
            }

            // 3) الحواف
            for (b in balls) {
                if (!b.alive) continue
                var x = b.pos.x; var y = b.pos.y
                var vx = b.vel.x; var vy = b.vel.y
                var hit = false
                if (x < minX) { x = minX; vx = -vx * rules.eCushion; hit = true }
                if (x > maxX) { x = maxX; vx = -vx * rules.eCushion; hit = true }
                if (y < minY) { y = minY; vy = -vy * rules.eCushion; hit = true }
                if (y > maxY) { y = maxY; vy = -vy * rules.eCushion; hit = true }
                if (hit) { b.pos = Vec(x, y); b.vel = Vec(vx, vy); events.add(b.id) }
            }

            // 4) تصادم الكرات
            for (i in balls.indices) {
                val a = balls[i]
                if (!a.alive) continue
                for (j in i + 1 until balls.size) {
                    val b = balls[j]
                    if (!b.alive) continue
                    val d = b.pos - a.pos
                    val dist = d.len()
                    if (dist >= 2 * r || dist == 0.0) continue
                    val n = d * (1.0 / dist)
                    val vn = (a.vel - b.vel).dot(n)
                    if (vn > 0) {
                        val k = (1 + rules.eBall) / 2 * vn
                        a.vel = a.vel - n * k
                        b.vel = b.vel + n * k
                        events.add(a.id); events.add(b.id)
                        if (contact == null && (a.id == 0 || b.id == 0)) {
                            val cue = if (a.id == 0) a else b
                            contact = cue.pos
                            target = if (a.id == 0) b.id else a.id
                        }
                    }
                    val overlap = (2 * r - dist) / 2
                    a.pos = a.pos - n * overlap
                    b.pos = b.pos + n * overlap
                }
            }

            // 5) تسجيل المسار
            val sample = step % sampleEvery == 0
            for (b in balls) if (b.alive && (sample || b.id in events)) paths[b.id]!!.add(b.pos)

            // 6) هل توقف كل شيء؟
            if (balls.all { !it.alive || it.vel.len() < rules.stopSpeed }) break
        }

        for (b in balls) if (b.alive) paths[b.id]!!.add(b.pos)
        return SimResult(paths, pocketed, contact, target)
    }
}
