package com.example.billiardhelper

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    companion object {
        private const val REQ_CAPTURE = 4242
    }

    private lateinit var keyBox: EditText
    private lateinit var modelBox: EditText
    private lateinit var status: TextView
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Speaker.prepare(this)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
        }

        fun lp() = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        fun label(msg: String, size: Float) {
            val tv = TextView(this)
            tv.text = msg
            tv.textSize = size
            tv.setPadding(0, pad / 2, 0, pad / 4)
            root.addView(tv, lp())
        }

        fun button(caption: String, action: () -> Unit) {
            val b = Button(this)
            b.text = caption
            b.setOnClickListener { action() }
            root.addView(b, lp())
        }

        label("Billiards Overlay + مدرّب ذكاء اصطناعي", 20f)
        label("اتبع الخطوات بالترتيب من 1 إلى 4", 14f)

        button("1) منح إذن الظهور فوق التطبيقات") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }

        label("2) مفتاح Groq واسم النموذج", 14f)
        keyBox = EditText(this)
        keyBox.hint = "الصق المفتاح هنا (gsk_...)"
        keyBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        root.addView(keyBox, lp())
        modelBox = EditText(this)
        modelBox.hint = "اسم النموذج"
        modelBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        modelBox.setText(AiSettings.model(this))
        root.addView(modelBox, lp())
        button("حفظ المفتاح والنموذج") { saveSettings() }
        button("اختبار المفتاح والصوت (بدون صورة)") { testKey() }

        button("3) تفعيل رؤية الذكاء الاصطناعي (التقاط الشاشة)") { requestCapture() }
        button("4) تشغيل الطبقة") { startOverlay() }
        button("تجربة كاملة: حلّل الطاولة بعد 5 ثوانٍ") { askAfterDelay() }
        button("إيقاف الطبقة والرؤية") { stopAll() }

        label("أدوات رسم المسار", 14f)
        button("تجربة رسم مثال") { sendDemo() }
        button("إخفاء الخطوط") { send(JSONObject().put("clear", true)) }

        status = TextView(this)
        status.textSize = 14f
        status.setTextIsSelectable(true)
        status.setPadding(0, pad, 0, 0)
        root.addView(status, lp())

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        refreshStatus(null)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus(null)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun refreshStatus(extra: String?) {
        val key = AiSettings.apiKey(this)
        val cap = CaptureService.instance
        val sb = StringBuilder()
        sb.append("المفتاح: ")
        sb.append(if (key.isEmpty()) "غير محفوظ" else AiSettings.mask(key))
        if (key.isNotEmpty() && key.length != 56) {
            sb.append("\nتنبيه: طول مفتاح Groq المعتاد 56 حرفاً. تأكد أنك نسخته كاملاً.")
        }
        sb.append("\nالنموذج: ").append(AiSettings.model(this))
        sb.append("\nرؤية الذكاء الاصطناعي: ")
        sb.append(if (cap != null && cap.isReady()) "تعمل" else "متوقفة")
        sb.append("\nالطبقة: ")
        sb.append(if (OverlayService.running) "تعمل" else "متوقفة")
        val err = CaptureService.lastError
        if (err != null) sb.append("\nآخر خطأ: ").append(err)
        if (extra != null) sb.append("\n\n").append(extra)
        status.text = sb.toString()
    }

    private fun saveSettings() {
        val typed = AiSettings.sanitizeKey(keyBox.text.toString())
        val oldKey = AiSettings.apiKey(this)
        val modelName = modelBox.text.toString().trim()
        AiSettings.save(this, if (typed.isEmpty()) oldKey else typed, modelName)
        keyBox.setText("")
        if (typed.isEmpty()) {
            refreshStatus("لم تُدخل مفتاحاً جديداً؛ بقي المفتاح المحفوظ كما هو.")
        } else {
            refreshStatus("تم حفظ المفتاح. اضغط «اختبار المفتاح والصوت» للتأكد.")
        }
    }

    private fun testKey() {
        val key = AiSettings.apiKey(this)
        if (key.isEmpty()) {
            refreshStatus("احفظ المفتاح أولاً.")
            return
        }
        val model = AiSettings.model(this)
        refreshStatus("أتصل بـ Groq...")
        Thread {
            try {
                val reply = GroqClient.ask(
                    key, model,
                    "أجب بجملة عربية واحدة قصيرة جداً: قل إن مدرّب البلياردو الذكي يعمل.",
                    null
                )
                Speaker.speak(reply)
                runOnUiThread { refreshStatus("نجح الاتصال.\nرد النموذج: " + reply) }
            } catch (e: AiException) {
                runOnUiThread { refreshStatus("فشل الاختبار: " + e.message) }
            } catch (e: Exception) {
                runOnUiThread {
                    refreshStatus("خطأ غير متوقع: " + e.javaClass.simpleName + " " + (e.message ?: ""))
                }
            }
        }.start()
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun requestCapture() {
        askNotificationPermission()
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode != RESULT_OK || data == null) {
            refreshStatus("لم تمنح إذن مشاركة الشاشة. اضغط الزر 3 وأعد المحاولة، واختر «الشاشة بالكامل».")
            return
        }
        CaptureService.lastError = null
        startForegroundService(
            Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
        )
        refreshStatus("جارٍ تفعيل الرؤية...")
        ui.postDelayed({ refreshStatus(null) }, 1200L)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            toast("امنح إذن الظهور فوق التطبيقات أولاً (الزر 1)")
            return
        }
        askNotificationPermission()
        startForegroundService(Intent(this, OverlayService::class.java))
        ui.postDelayed({ refreshStatus(null) }, 800L)
    }

    private fun askAfterDelay() {
        if (!OverlayService.running) {
            toast("شغّل الطبقة أولاً (الزر 4)")
            return
        }
        sendBroadcast(
            Intent(OverlayService.ACTION_SHOT)
                .setPackage(packageName)
                .putExtra("delayMs", 5000L)
        )
        toast("انتقل إلى اللعبة الآن؛ سيحلل الذكاء الاصطناعي الشاشة بعد 5 ثوانٍ")
    }

    private fun stopAll() {
        stopService(Intent(this, OverlayService::class.java))
        stopService(Intent(this, CaptureService::class.java))
        ui.postDelayed({ refreshStatus("تم الإيقاف.") }, 500L)
    }

    private fun send(json: JSONObject) {
        sendBroadcast(
            Intent(OverlayService.ACTION_UPDATE)
                .setPackage(packageName)
                .putExtra("json", json.toString())
        )
    }

    /** مثال: بيضاء تضرب كرة قريبة من منتصف الطاولة */
    private fun sendDemo() {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toDouble()
        val h = dm.heightPixels.toDouble()
        val l = w * 0.1; val r = w * 0.9; val t = h * 0.15; val b = h * 0.85
        val ballR = minOf(w, h) * 0.035
        val midY = (t + b) / 2

        fun ball(id: Int, x: Double, y: Double) = JSONObject().put("id", id).put("x", x).put("y", y)

        val json = JSONObject()
            .put("table", JSONObject().put("l", l).put("t", t).put("r", r).put("b", b).put("ballR", ballR))
            .put("balls", JSONArray()
                .put(ball(0, l + (r - l) * 0.20, midY))
                .put(ball(1, l + (r - l) * 0.50, midY + ballR * 0.8))
                .put(ball(2, l + (r - l) * 0.70, midY - ballR * 3)))
            .put("aim", JSONObject().put("dx", 1.0).put("dy", 0.0).put("speed", w * 1.2))
            .put("friction", w * 0.35)
        send(json)
    }
}
