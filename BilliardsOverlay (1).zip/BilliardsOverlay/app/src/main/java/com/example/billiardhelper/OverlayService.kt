package com.example.billiardhelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val ACTION_UPDATE = "com.example.billiardhelper.UPDATE"

        /** تُرسلها لعبتك عند كل ضربة: يلتقط الذكاء الاصطناعي الشاشة ويعلّق صوتياً */
        const val ACTION_SHOT = "com.example.billiardhelper.SHOT"

        /** مثل SHOT لكن بلا تأخير (يستخدمها زر AI العائم) */
        const val ACTION_ASK = "com.example.billiardhelper.ASK_AI"

        private const val CHANNEL = "overlay"
        private const val TAG = "BilliardsOverlay"

        @Volatile
        var running: Boolean = false
    }

    private lateinit var wm: WindowManager
    private var view: TrajectoryView? = null
    private var panel: LinearLayout? = null
    private var bubble: TextView? = null
    private var panelLp: WindowManager.LayoutParams? = null

    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val aiWorker = Executors.newSingleThreadExecutor()
    private val latest = AtomicReference<String?>(null)
    private val busy = AtomicBoolean(false)

    private val hideBubble = Runnable { bubble?.visibility = View.GONE }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ACTION_UPDATE -> {
                    val json = intent.getStringExtra("json") ?: return
                    latest.set(json)                       // نحتفظ بآخر رسالة فقط
                    worker.execute { latest.getAndSet(null)?.let { handle(it) } }
                }
                ACTION_SHOT -> askAi(intent.getLongExtra("delayMs", 0L), intent.getStringExtra("note"))
                ACTION_ASK -> askAi(0L, null)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundCompat()
        Speaker.prepare(this)
        addOverlay()
        addPanel()
        val filter = IntentFilter()
        filter.addAction(ACTION_UPDATE)
        filter.addAction(ACTION_SHOT)
        filter.addAction(ACTION_ASK)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_EXPORTED)
        else registerReceiver(receiver, filter)
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        running = false
        try {
            unregisterReceiver(receiver)
        } catch (e: Exception) {
            Log.w(TAG, "unregisterReceiver", e)
        }
        ui.removeCallbacks(hideBubble)
        Speaker.stop()
        view?.let { wm.removeView(it) }
        view = null
        panel?.let { wm.removeView(it) }
        panel = null
        bubble = null
        worker.shutdownNow()
        aiWorker.shutdownNow()
        super.onDestroy()
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Billiards Overlay يعمل")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** نافذة الخطوط: ملء الشاشة وبلا لمس (اللمس يمر للعبة) */
    private fun addOverlay() {
        val v = TrajectoryView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or      // اللمس يمر للعبة
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        // أندرويد 12+: النافذة غير القابلة للّمس تحجب لمس اللعبة إن زادت شفافيتها عن 0.8
        lp.alpha = 0.8f
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        view = v
    }

    /** نافذة صغيرة قابلة للّمس: زر AI عائم (يُسحب) + فقاعة نص النصيحة */
    private fun addPanel() {
        val btn = TextView(this)
        btn.text = "AI"
        btn.setTextColor(Color.WHITE)
        btn.textSize = 15f
        btn.typeface = Typeface.DEFAULT_BOLD
        btn.gravity = Gravity.CENTER
        val round = GradientDrawable()
        round.setShape(GradientDrawable.OVAL)
        round.setColor(Color.argb(210, 21, 101, 192))
        btn.background = round
        btn.layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))

        val tv = TextView(this)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 15f
        tv.setPadding(dp(12), dp(8), dp(12), dp(8))
        tv.maxWidth = dp(300)
        val card = GradientDrawable()
        card.setCornerRadius(dp(12).toFloat())
        card.setColor(Color.argb(225, 0, 0, 0))
        tv.background = card
        tv.visibility = View.GONE
        tv.setOnClickListener {
            ui.removeCallbacks(hideBubble)
            tv.visibility = View.GONE
            Speaker.stop()
        }

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.addView(btn)
        box.addView(tv)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(12)
        lp.y = dp(60)
        panelLp = lp

        // سحب الزر لتحريكه، ونقرة قصيرة لسؤال الذكاء الاصطناعي
        btn.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var downX = 0f
            private var downY = 0f
            private var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val params = panelLp ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        downX = e.rawX
                        downY = e.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - downX).toInt()
                        val dy = (e.rawY - downY).toInt()
                        if (abs(dx) > 12 || abs(dy) > 12) moved = true
                        if (moved) {
                            params.x = maxOf(0, startX + dx)
                            params.y = maxOf(0, startY + dy)
                            panel?.let { wm.updateViewLayout(it, params) }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) askAi(0L, null)
                        return true
                    }
                }
                return false
            }
        })

        wm.addView(box, lp)
        panel = box
        bubble = tv
    }

    // ───────────────────────── الذكاء الاصطناعي ─────────────────────────

    private fun askAi(delayMs: Long, note: String?) {
        if (!busy.compareAndSet(false, true)) {
            showBubble("ما زلت أحلل الطلب السابق، انتظر لحظة.")
            return
        }
        try {
            aiWorker.execute {
                try {
                    runAi(delayMs, note)
                } finally {
                    busy.set(false)
                }
            }
        } catch (e: Exception) {
            busy.set(false)
            Log.e(TAG, "تعذّر جدولة طلب الذكاء الاصطناعي", e)
        }
    }

    /** يعمل في خيط خلفي: التقاط الشاشة ثم Groq ثم عرض النصيحة ونطقها */
    private fun runAi(delayMs: Long, note: String?) {
        try {
            val key = AiSettings.apiKey(this)
            if (key.isEmpty()) {
                say("أدخل مفتاح Groq داخل التطبيق ثم اضغط حفظ.")
                return
            }
            val cap = CaptureService.instance
            if (cap == null || !cap.isReady()) {
                say("رؤية الذكاء الاصطناعي غير مفعلة. افتح التطبيق واضغط الزر 3.")
                return
            }
            if (delayMs > 0) Thread.sleep(delayMs)

            showBubble("أحلل الطاولة...")
            setOverlayHidden(true)      // نخفي الخطوط والزر حتى لا يراها النموذج
            val jpeg = try {
                cap.grabJpeg()
            } finally {
                setOverlayHidden(false)
            }
            if (jpeg == null) {
                say("تعذّر التقاط الشاشة. أعد تفعيل الرؤية من التطبيق.")
                return
            }
            val reply = GroqClient.ask(key, AiSettings.model(this), buildPrompt(note), jpeg)
            say(reply)
        } catch (e: AiException) {
            Log.w(TAG, "AI error: " + e.message)
            say(e.message ?: "خطأ غير معروف")
        } catch (e: InterruptedException) {
            Log.i(TAG, "AI request interrupted")
        } catch (e: Exception) {
            Log.e(TAG, "AI failure", e)
            say("حدث خطأ غير متوقع: " + e.javaClass.simpleName)
        }
    }

    private fun buildPrompt(note: String?): String {
        val sb = StringBuilder()
        sb.append("أنت مدرّب بلياردو خبير، وهذه لقطة شاشة من لعبة بلياردو على الهاتف. ")
        sb.append("انظر إلى الطاولة وأعطني نصيحة للضربة القادمة بالعربية فقط، في جملتين أو ثلاث وبأقل من 45 كلمة: ")
        sb.append("أين الكرة البيضاء، وأي كرة أستهدف، وإلى أي جيب، وهل هناك خطر مثل دخول البيضاء في الجيب. ")
        sb.append("تجاهل أي خطوط ملونة أو أزرار أو نصوص عائمة فوق اللعبة. ")
        sb.append("إن لم تظهر طاولة بلياردو في الصورة فقل ذلك بصراحة ولا تخترع تفاصيل غير واضحة. ")
        sb.append("لا تستخدم رموزاً تعبيرية ولا تنسيقاً خاصاً.")
        if (!note.isNullOrBlank()) {
            sb.append(" معلومة من اللعبة: ").append(note)
        }
        return sb.toString()
    }

    /** يخفي/يُظهر الخطوط والزر، وينتظر قليلاً ليصل إطار جديد بدونهما */
    private fun setOverlayHidden(hidden: Boolean) {
        val done = CountDownLatch(1)
        ui.post {
            val vis = if (hidden) View.INVISIBLE else View.VISIBLE
            view?.visibility = vis
            panel?.visibility = vis
            done.countDown()
        }
        done.await(1, TimeUnit.SECONDS)
        if (hidden) Thread.sleep(250)
    }

    private fun say(text: String) {
        showBubble(text)
        Speaker.speak(text)
    }

    private fun showBubble(text: String) {
        ui.post {
            val b = bubble ?: return@post
            b.text = text
            b.visibility = View.VISIBLE
            ui.removeCallbacks(hideBubble)
            ui.postDelayed(hideBubble, 15000L)
        }
    }

    // ───────────────────────── رسم المسارات (كما كان) ─────────────────────────

    /** يحلل الرسالة، يشغل المحاكاة، ويرسم النتيجة */
    private fun handle(text: String) {
        try {
            val o = JSONObject(text)
            if (o.optBoolean("clear", false)) { view?.clear(); return }

            val tb = o.getJSONObject("table")
            val l = tb.getDouble("l"); val t = tb.getDouble("t")
            val rr = tb.getDouble("r"); val b = tb.getDouble("b")
            val ballR = tb.getDouble("ballR")
            val pocketR = tb.optDouble("pocketR", ballR * 1.6)

            val pockets = ArrayList<Vec>()
            if (o.has("pockets")) {
                val arr = o.getJSONArray("pockets")
                for (i in 0 until arr.length()) {
                    val p = arr.getJSONArray(i)
                    pockets.add(Vec(p.getDouble(0), p.getDouble(1)))
                }
            } else {
                val mx = (l + rr) / 2
                pockets.addAll(listOf(
                    Vec(l, t), Vec(mx, t), Vec(rr, t),
                    Vec(l, b), Vec(mx, b), Vec(rr, b)
                ))
            }
            val table = Table(l, t, rr, b, ballR, pockets, pocketR)

            val aim = o.getJSONObject("aim")
            val dir = Vec(aim.getDouble("dx"), aim.getDouble("dy")).norm()
            val speed = aim.getDouble("speed")

            val arr = o.getJSONArray("balls")
            val balls = ArrayList<Ball>()
            for (i in 0 until arr.length()) {
                val ob = arr.getJSONObject(i)
                val id = ob.getInt("id")
                val pos = Vec(ob.getDouble("x"), ob.getDouble("y"))
                balls.add(Ball(id, pos, if (id == 0) dir * speed else Vec(0.0, 0.0)))
            }

            val rules = Rules(
                friction = o.optDouble("friction", 600.0),
                eBall = o.optDouble("eBall", 0.95),
                eCushion = o.optDouble("eCushion", 0.75)
            )
            view?.show(Sim.run(balls, table, rules), ballR)
        } catch (e: Exception) {
            Log.e(TAG, "رسالة غير صالحة", e)
        }
    }
}
