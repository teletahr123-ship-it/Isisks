package com.example.billiardhelper

import android.util.Base64
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** خطأ برسالة عربية جاهزة للعرض على المستخدم */
class AiException(message: String) : Exception(message)

/** رد HTTP غير ناجح من الخادم */
internal class HttpFailure(val code: Int, val body: String, val retryAfter: String?) :
    Exception("HTTP " + code)

/**
 * عميل Groq (واجهة متوافقة مع OpenAI).
 * ملاحظة: كل التعليمات توضع في رسالة المستخدم لأن توصية Groq تجنّب رسائل system مع هذه النماذج.
 */
object GroqClient {

    private const val ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"

    /** يرسل نصاً وصورة JPEG اختيارية، ويعيد نص الرد. يرمي AiException برسالة عربية واضحة. */
    fun ask(apiKey: String, model: String, prompt: String, jpeg: ByteArray?): String {
        if (apiKey.isBlank()) {
            throw AiException("لم تحفظ مفتاح Groq بعد. الصقه في التطبيق ثم اضغط حفظ.")
        }
        val imageUrl: String? =
            if (jpeg != null) "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP) else null

        val reply: String = try {
            try {
                clean(extract(post(apiKey, buildBody(model, prompt, imageUrl, true))))
            } catch (e: HttpFailure) {
                // بعض النماذج لا تقبل reasoning_effort: نعيد المحاولة بدونه مرة واحدة
                if (e.code == 400 && e.body.contains("reasoning", ignoreCase = true)) {
                    clean(extract(post(apiKey, buildBody(model, prompt, imageUrl, false))))
                } else {
                    throw e
                }
            }
        } catch (e: HttpFailure) {
            throw AiException(explain(e))
        } catch (e: JSONException) {
            throw AiException("وصل رد غير مفهوم من الخادم. أعد المحاولة.")
        } catch (e: IOException) {
            throw AiException("تعذّر الاتصال بالإنترنت أو انتهت المهلة. تحقق من الشبكة وأعد المحاولة.")
        }
        return reply
    }

    private fun buildBody(model: String, prompt: String, imageUrl: String?, noReasoning: Boolean): JSONObject {
        val message = JSONObject().put("role", "user")
        if (imageUrl == null) {
            message.put("content", prompt)
        } else {
            val parts = JSONArray()
            parts.put(JSONObject().put("type", "text").put("text", prompt))
            parts.put(
                JSONObject()
                    .put("type", "image_url")
                    .put("image_url", JSONObject().put("url", imageUrl))
            )
            message.put("content", parts)
        }
        val body = JSONObject()
        body.put("model", model)
        body.put("messages", JSONArray().put(message))
        body.put("temperature", 0.7)
        body.put("top_p", 0.8)
        body.put("max_completion_tokens", 250)
        // وضع التعليمات السريع (بدون تفكير طويل) لنموذج Qwen 3.8
        if (noReasoning) body.put("reasoning_effort", "none")
        return body
    }

    private fun post(apiKey: String, body: JSONObject): String {
        val conn = URL(ENDPOINT).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer " + apiKey)
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("User-Agent", "BilliardsOverlay/1.1 (Android)")
            val bytes = body.toString().toByteArray(Charsets.UTF_8)
            conn.setFixedLengthStreamingMode(bytes.size)
            conn.outputStream.use { it.write(bytes) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = if (stream != null) stream.bufferedReader(Charsets.UTF_8).use { it.readText() } else ""
            if (code !in 200..299) {
                throw HttpFailure(code, text, conn.getHeaderField("retry-after"))
            }
            return text
        } finally {
            conn.disconnect()
        }
    }

    private fun extract(json: String): String {
        val root = JSONObject(json)
        val choices = root.optJSONArray("choices")
        if (choices == null || choices.length() == 0) {
            throw AiException("رد فارغ من الخادم. أعد المحاولة.")
        }
        val msg = choices.getJSONObject(0).optJSONObject("message")
            ?: throw AiException("رد غير متوقع من الخادم. أعد المحاولة.")
        return if (msg.isNull("content")) "" else msg.getString("content")
    }

    /** يزيل أي كتل تفكير ورموز تنسيق (حتى لا يقرأها الصوت) */
    private fun clean(raw: String): String {
        var t = raw
        t = t.replace(Regex("(?s)<think>.*?</think>"), "")
        val open = t.indexOf("<think>")
        if (open >= 0) t = t.substring(0, open)
        t = t.replace(Regex("[*#`]"), "")
        t = t.replace(Regex("\\s+"), " ").trim()
        if (t.isEmpty()) {
            throw AiException("النموذج لم يُرجع نصاً. أعد المحاولة.")
        }
        return t
    }

    private fun explain(f: HttpFailure): String {
        val low = f.body.lowercase()
        if (low.contains("decommission") || low.contains("model_not_found") || low.contains("does not exist")) {
            return "النموذج غير متاح في Groq (ربما أُلغي). غيّر اسم النموذج في التطبيق إلى " +
                AiSettings.DEFAULT_MODEL + " أو اختر نموذجاً يدعم الصور من console.groq.com/docs/models"
        }
        val detail = errorMessage(f.body)
        return when (f.code) {
            401 -> "المفتاح غير صالح أو ملغى (401). أنشئ مفتاحاً جديداً من console.groq.com ثم احفظه في التطبيق."
            403 -> "الوصول مرفوض (403). تحقق من صلاحيات المفتاح والنموذج في حسابك. " + detail
            404 -> "عنوان أو نموذج غير موجود (404). " + detail
            413 -> "الطلب كبير جداً (413). أعد المحاولة."
            429 -> {
                val wait = f.retryAfter
                if (wait != null) {
                    "تجاوزت حد الطلبات المجاني (429). انتظر " + wait + " ثانية ثم أعد المحاولة."
                } else {
                    "تجاوزت حد الطلبات المجاني (429). انتظر قليلاً ثم أعد المحاولة."
                }
            }
            in 500..599 -> "خدمة Groq مشغولة حالياً (" + f.code + "). أعد المحاولة بعد قليل."
            else -> "خطأ من Groq (" + f.code + "): " + detail
        }
    }

    private fun errorMessage(body: String): String {
        return try {
            val m = JSONObject(body).optJSONObject("error")?.optString("message", "") ?: ""
            if (m.isEmpty()) body.take(200) else m.take(300)
        } catch (e: Exception) {
            body.take(200)
        }
    }
}
