package com.example.billiardhelper

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import java.io.ByteArrayOutputStream
import kotlin.math.max

/**
 * يلتقط الشاشة عبر MediaProjection ويحتفظ بآخر إطار فقط (بدون تحويله إلى صورة حتى لا يثقل اللعبة).
 * عند الطلب يحوّل آخر إطار إلى JPEG مصغّر عبر grabJpeg().
 */
class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "capture"
        private const val TAG = "BilliardsCapture"
        private const val MAX_SIDE = 1280

        @Volatile
        var instance: CaptureService? = null

        @Volatile
        var lastError: String? = null
    }

    private val lock = Any()
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var latestImage: Image? = null
    private var curW = 0
    private var curH = 0
    private var thread: HandlerThread? = null
    private var bg: Handler? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        val t = HandlerThread("capture-bg")
        t.start()
        thread = t
        bg = Handler(t.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // بعد startForegroundService يجب استدعاء startForeground فوراً وإلا ينهار التطبيق
        try {
            startAsForeground()
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
            lastError = "تعذّر بدء خدمة الالتقاط: " + e.javaClass.simpleName
            stopSelf()
            return START_NOT_STICKY
        }

        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = readConsent(intent)
        if (code != Activity.RESULT_OK || data == null) {
            lastError = "لم يصل إذن التقاط الشاشة. اضغط الزر 3 من جديد."
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            lastError = null
            cleanup() // إن كان هناك التقاط سابق نغلقه قبل البدء من جديد
            startProjection(code, data)
        } catch (e: Exception) {
            Log.e(TAG, "startProjection failed", e)
            lastError = "فشل بدء التقاط الشاشة: " + e.javaClass.simpleName + " " + (e.message ?: "")
            cleanup()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        cleanup()
        instance = null
        thread?.quitSafely()
        thread = null
        bg = null
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun readConsent(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else i?.getParcelableExtra(EXTRA_DATA)

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "AI Vision", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("رؤية الذكاء الاصطناعي تعمل")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(2, n)
        }
    }

    private fun startProjection(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp: MediaProjection = mpm.getMediaProjection(code, data)
            ?: throw IllegalStateException("MediaProjection is null")

        val cb = object : MediaProjection.Callback() {
            override fun onStop() {
                Log.i(TAG, "projection stopped")
                lastError = "توقفت مشاركة الشاشة (أوقفها النظام أو المستخدم). فعّل الرؤية من جديد."
                cleanup()
                stopSelf()
            }
        }
        projection = mp
        projectionCallback = cb
        // أندرويد 14+: يجب تسجيل callback قبل إنشاء VirtualDisplay
        mp.registerCallback(cb, bg)

        val m = realMetrics()
        val size = scaledSize(m.widthPixels, m.heightPixels)
        buildDisplay(size[0], size[1], m.densityDpi)
    }

    private fun buildDisplay(w: Int, h: Int, dpi: Int) {
        synchronized(lock) {
            val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
            reader.setOnImageAvailableListener({ r -> onFrame(r) }, bg)
            imageReader = reader
            virtualDisplay = projection?.createVirtualDisplay(
                "ai-vision", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, bg
            )
            curW = w
            curH = h
        }
    }

    /** نحتفظ بآخر إطار فقط: نغلق القديم عند وصول جديد */
    private fun onFrame(r: ImageReader) {
        val image: Image? = try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            Log.w(TAG, "acquireLatestImage failed", e)
            null
        }
        if (image == null) return
        synchronized(lock) {
            if (r !== imageReader) {
                image.close() // قارئ قديم بعد تغيير حجم الشاشة
                return
            }
            latestImage?.close()
            latestImage = image
        }
    }

    fun isReady(): Boolean = synchronized(lock) { projection != null && virtualDisplay != null }

    /** يعيد JPEG مصغّراً للشاشة الحالية أو null إن تعذّر. يُستدعى من خيط خلفي (ليس الرئيسي). */
    fun grabJpeg(): ByteArray? {
        if (!isReady()) return null
        resizeIfNeeded()

        // انتظر وصول إطار (بعد تغيير الحجم أو في البداية)
        var waited = 0
        while (waited < 2500) {
            val has = synchronized(lock) { latestImage != null }
            if (has) break
            Thread.sleep(50)
            waited += 50
        }

        val bmp: Bitmap = synchronized(lock) {
            val img = latestImage ?: return null
            toBitmap(img)
        }
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        bmp.recycle()
        return out.toByteArray()
    }

    private fun toBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        val buf = plane.buffer
        buf.rewind()
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * img.width
        val wide = Bitmap.createBitmap(
            img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
        )
        wide.copyPixelsFromBuffer(buf)
        if (rowPadding == 0) return wide
        val cropped = Bitmap.createBitmap(wide, 0, 0, img.width, img.height)
        wide.recycle()
        return cropped
    }

    /** إن دارت الشاشة (عمودي <-> أفقي) نغيّر حجم الالتقاط ليطابقها */
    private fun resizeIfNeeded() {
        val m = realMetrics()
        val size = scaledSize(m.widthPixels, m.heightPixels)
        synchronized(lock) {
            val vd = virtualDisplay ?: return
            if (size[0] == curW && size[1] == curH) return
            val old = imageReader
            val reader = ImageReader.newInstance(size[0], size[1], PixelFormat.RGBA_8888, 3)
            reader.setOnImageAvailableListener({ r -> onFrame(r) }, bg)
            vd.resize(size[0], size[1], m.densityDpi)
            vd.setSurface(reader.surface)
            latestImage?.close()
            latestImage = null
            imageReader = reader
            old?.close()
            curW = size[0]
            curH = size[1]
        }
    }

    private fun cleanup() {
        synchronized(lock) {
            val p = projection
            val cb = projectionCallback
            projection = null
            projectionCallback = null
            // نلغي تسجيل callback أولاً حتى لا يعيد stop() استدعاء onStop
            if (p != null && cb != null) {
                try {
                    p.unregisterCallback(cb)
                } catch (e: Exception) {
                    Log.w(TAG, "unregisterCallback", e)
                }
            }
            try {
                virtualDisplay?.release()
            } catch (e: Exception) {
                Log.w(TAG, "release display", e)
            }
            virtualDisplay = null
            try {
                latestImage?.close()
            } catch (e: Exception) {
                Log.w(TAG, "close image", e)
            }
            latestImage = null
            try {
                imageReader?.close()
            } catch (e: Exception) {
                Log.w(TAG, "close reader", e)
            }
            imageReader = null
            try {
                p?.stop()
            } catch (e: Exception) {
                Log.w(TAG, "stop projection", e)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun realMetrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        val dsp = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        dsp.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        return dm
    }

    private fun scaledSize(w: Int, h: Int): IntArray {
        val longSide = max(w, h)
        val k = if (longSide > MAX_SIDE) MAX_SIDE.toDouble() / longSide.toDouble() else 1.0
        val nw = max(16, (w * k).toInt())
        val nh = max(16, (h * k).toInt())
        return intArrayOf(nw, nh)
    }
}
