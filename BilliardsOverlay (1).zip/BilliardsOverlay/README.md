# Billiards Overlay + مدرّب ذكاء اصطناعي

تطبيق Android يرسم خطوط مسار الكرات فوق لعبتك، وفيه الآن **مدرّب ذكاء اصطناعي**:
زر عائم "AI" يلتقط الشاشة، يرسلها إلى Groq (نموذج `qwen/qwen3.8-27b`)، ثم يعرض النصيحة **ويقرؤها بالصوت العربي**.
ولعبتك تستطيع استدعاءه تلقائياً عند **كل ضربة**.

## البناء بدون Android Studio (GitHub Actions — يعمل من الآيباد)
1. أنشئ حساباً على github.com ثم مستودعاً جديداً (اجعله Private).
2. في المستودع: **Add file ← Upload files** ثم ارفع ملف `BilliardsOverlay.zip` كما هو (لا تفكّه) واضغط Commit.
3. **Add file ← Create new file**، اكتب في خانة الاسم: `.github/workflows/build.yml` والصق محتوى الملف الموجود في هذا المشروع ثم Commit.
4. افتح تبويب **Actions**؛ انتظر 3–6 دقائق حتى تظهر علامة ✓ خضراء.
5. افتح التشغيل الناجح ← أسفل الصفحة **Artifacts** ← `BilliardsOverlay-APK` ← حمّله على هاتف الأندرويد، فُكّ الضغط، وثبّت `app-debug.apk`.

كل نسخة جديدة تُثبَّت فوق القديمة مباشرة (التوقيع ثابت) وتبقى إعداداتك محفوظة.
بديل: افتح المجلد في Android Studio (JDK 17) ← Run.

## التشغيل على الهاتف (بهذا الترتيب)
1. **منح إذن الظهور فوق التطبيقات** ثم ارجع للتطبيق.
2. الصق مفتاح Groq واضغط **حفظ**، ثم **اختبار المفتاح والصوت** (يجب أن تسمع جملة عربية).
3. **تفعيل رؤية الذكاء الاصطناعي**: اختر **الشاشة بالكامل** ثم **ابدأ الآن**.
4. **تشغيل الطبقة** ← يظهر زر **AI** أزرق (اسحبه لتحريكه).
5. افتح لعبتك واضغط الزر: يحلل الطاولة ويعرض النصيحة ويقرؤها. اضغط الفقاعة لإخفائها.

المفتاح لا يوجد داخل الكود عمداً؛ يُحفظ في مساحة التطبيق الخاصة على هاتفك فقط، فلا يتسرب إن رفعت المشروع إلى GitHub.

## ربط لعبتك: تعليق عند كل ضربة
```kotlin
fun onShotTaken(ctx: Context) {
    ctx.sendBroadcast(
        Intent("com.example.billiardhelper.SHOT")
            .setPackage("com.example.billiardhelper")
            .putExtra("delayMs", 1500L)            // اختياري: انتظر حتى تهدأ الكرات
            .putExtra("note", "دور اللاعب الأول")   // اختياري: معلومة تُضاف للسؤال
    )
}
```

## رسم المسارات (كما كان)
لعبتك ترسل Broadcast `com.example.billiardhelper.UPDATE` فيه JSON بالإحداثيات (بكسل على الشاشة):
```kotlin
val json = JSONObject()
    .put("table", JSONObject().put("l", 120).put("t", 90).put("r", 1800).put("b", 990).put("ballR", 22))
    .put("balls", JSONArray()
        .put(JSONObject().put("id", 0).put("x", 400).put("y", 540))   // id 0 = البيضاء
        .put(JSONObject().put("id", 1).put("x", 900).put("y", 560)))
    .put("aim", JSONObject().put("dx", 1.0).put("dy", 0.0).put("speed", 2200))
    .put("friction", 600)
ctx.sendBroadcast(
    Intent("com.example.billiardhelper.UPDATE")
        .setPackage("com.example.billiardhelper")
        .putExtra("json", json.toString())
)
// لإخفاء الخطوط: {"clear": true}
```
حقول اختيارية: `pockets` (مصفوفة [x,y])، `pocketR`، `eBall`، `eCushion`. الدوران (Spin) غير مدعوم.

## حدود Groq المجانية وأخطاء شائعة
- الباقة المجانية للنموذج الحالي: نحو 30 طلباً/دقيقة لكن **8 آلاف توكن/دقيقة** و**200 ألف توكن/يوم**؛ والصورة الواحدة تحسب 2048 توكن، أي نحو 3 طلبات في الدقيقة وحوالي 70–80 طلباً يومياً.
- `401`: المفتاح خاطئ أو ملغى ← أنشئ مفتاحاً جديداً. `429`: تجاوزت الحد ← انتظر. 
- "النموذج غير متاح": نماذج Llama 4 (Scout/Maverick) أُوقفت في Groq؛ استخدم `qwen/qwen3.8-27b` أو راجع console.groq.com/docs/models.
- صوت صامت: ثبّت صوت العربية من إعدادات الهاتف ← تحويل النص إلى كلام.
- صورة سوداء: بعض الألعاب تمنع التقاط الشاشة.
